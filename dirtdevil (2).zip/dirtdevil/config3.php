<?php 

$server = "sql202.epizy.com";
$user = "epiz_32368898";
$pass = "EnQ0swebAH8uiVy";
$database = "epiz_32368898_dirtdevils";

$conn = mysqli_connect($server, $user, $pass, $database);

if (!$conn) {
    die("<script>alert('Connection Failed.')</script>");
}

?>