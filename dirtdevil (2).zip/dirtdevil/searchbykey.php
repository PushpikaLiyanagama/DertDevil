<?php
	
	include 'config3.php';
	$key = $_POST['key'];
	$sql = "select * from employeesdata where emp_area = '$key'";
	$result = $conn->query($sql);

	if($result->num_rows>0){

		echo '<table border = 1>';
			echo '<tr>
					<th>Employee Name</th>
					<th>Employee Age</th>
					<th>Employee Working Area</th>
					<th>Employee Contact Number</th>
					<th>Description</th>
				</tr>';

				While($row = $result->fetch_assoc()){
					echo '<tr>
							<td>'.$row['emp_name'].'</td>
							<td>'.$row['emp_age'].'</td>
							<td>'.$row['emp_area'].'</td>
							<td>'.$row['emp_contact'].'</td>
							<td>'.$row['emp_description'].'</td>
						</tr>';
				}
		echo '</table>';


	}else{
		echo 'Search Area Not Defined'; 
	}
?>