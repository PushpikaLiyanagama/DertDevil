<?php

	include 'config3.php';

	$emp_name = $_POST['empName'];
	$emp_age = $_POST['empAge'];
	$emp_area = $_POST['empArea'];
	$emp_contact = $_POST['empContact'];
	$emp_description = $_POST['empDescription'];

	$sql = "insert into employeesdata(emp_name , emp_age ,	emp_area , emp_contact , emp_description) values(?,?,?,?,?)";
	$statment = $conn->prepare($sql);

	$statment ->bind_param("sssss", $emp_name, $emp_age, $emp_area, $emp_contact, $emp_description); 

	if($statment->execute()){
		echo 'Insert Data Sucess';
	}else{
		echo 'Incert Data Error';
	}

?>
