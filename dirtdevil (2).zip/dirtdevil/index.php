<!DOCTYPE html>
<html>
<head>
	
	<title>Page-01</title>
	<link rel ="stylesheet" type="text/css" href="./style.css">
	<style>
		body{background-image:url("back2.jpg");
		background-repeat:no-repeat;
		background-attachment:fixed;
		background-size:cover;}

	</style>
	
</head>
<body>
	<div class="page1">
		<h1>Welcome To Our Clearning Service</h1>
		<a href="./index4.php">
		<button type="submit">Get Service</button>
		</a>
		<a href="./index3.php">
		<button type="submit">Pablish your Advertiesment</button>
		</a>
	
		
	</div>


</body>
</html>